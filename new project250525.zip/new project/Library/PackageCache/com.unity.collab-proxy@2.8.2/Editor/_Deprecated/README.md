Deprecated public classes that we need to keep until we change the major version of the package to 3.x.
Removing any public API in a minor version is forbidden.

The issue is that updating the major version of a default package is forbidden in a stable Unity Editor version,
so we cannot do it during the lifetime of Unity 6.x.
