using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LargePotion : Potion
{
    public override void FillHp()
    {
        Debug.Log("100HP ȸ��");
    }
}
