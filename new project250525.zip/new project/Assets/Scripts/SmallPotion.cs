using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SmallPotion : Potion
{
    public override void FillHp()
    {
        Debug.Log("20HP ȸ��");
    }
}
