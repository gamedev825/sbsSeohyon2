using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Potion
{

    public virtual void FillHp()
    {
        Debug.Log("HPȸ��");
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }


}
